import { deleteTask, updateTask } from "../api/tasks";

export default function TaskItem({ task, onUpdate }) {
  const toggleStatus = async () => {
    const nextStatus =
      task.status === "todo"
        ? "in-progress"
        : task.status === "in-progress"
        ? "done"
        : "todo";
    await updateTask(task.id, { status: nextStatus });
    onUpdate();
  };

  const removeTask = async () => {
    await deleteTask(task.id);
    onUpdate();
  };

  const statusColors = {
    todo: "text-red-500",
    "in-progress": "text-yellow-500",
    done: "text-green-500",
  };

  return (
    <div className="flex justify-between items-center border p-2 rounded my-1">
      <div>
        <span className={`font-bold ${statusColors[task.status]}`}>
          {task.status}
        </span>{" "}
        - {task.description}
      </div>
      <div className="flex gap-2">
        <button
          onClick={toggleStatus}
          className="bg-yellow-400 px-2 rounded text-black"
        >
          Next
        </button>
        <button
          onClick={removeTask}
          className="bg-red-500 px-2 rounded text-white"
        >
          Delete
        </button>
      </div>
    </div>
  );
}
