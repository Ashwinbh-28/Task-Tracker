import { useState } from "react";
import { addTask } from "../api/tasks";

export default function TaskForm({ onTaskAdded }) {
  const [desc, setDesc] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!desc.trim()) return;
    await addTask(desc);
    setDesc("");
    onTaskAdded();
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="text"
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
        placeholder="Add a task..."
        className="border p-2 rounded flex-1"
      />
      <button
        type="button"
        onClick={handleSubmit}
        className="bg-blue-500 text-white px-4 rounded cursor-pointer"
      >
        Add
      </button>
    </form>
  );
}
