import { useEffect, useState } from "react";
import { getTasks } from "../api/tasks";
import TaskForm from "./TaskForm";
import TaskItem from "./TaskItem";
import FilterButtons from "./FilterButtons";
import BottomBar from "./BottomBar";

export default function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState("all");

  const fetchTasks = async () => {
    const res = await getTasks();
    let data = res.data;
    if (filter !== "all") {
      data = data.filter((task) => task.status === filter);
    }
    setTasks(data);
  };

  useEffect(() => {
    fetchTasks();
  }, [filter]);

  return (
    <div className="max-w-md mx-auto p-4 pb-16">
      <h1 className="text-2xl font-bold text-center mb-4">Task Tracker</h1>
      <TaskForm onTaskAdded={fetchTasks} />
      <FilterButtons filter={filter} setFilter={setFilter} />
      <div className="mt-4">
        {tasks.length === 0 ? (
          <p className="text-center text-gray-500">No tasks found</p>
        ) : (
          tasks.map((task) => (
            <TaskItem key={task.id} task={task} onUpdate={fetchTasks} />
          ))
        )}
      </div>
      <BottomBar filter={filter} setFilter={setFilter} />
    </div>
  );
}
