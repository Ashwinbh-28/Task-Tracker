export default function FilterButtons({ filter, setFilter }) {
  const statuses = ["all", "todo", "in-progress", "done"];

  return (
    <div className="flex justify-center gap-2 mt-4 flex-wrap">
      {statuses.map((status) => (
        <button
          key={status}
          onClick={() => setFilter(status)}
          className={`px-3 py-1 rounded ${
            filter === status ? "bg-blue-500 text-white" : "bg-gray-200"
          }`}
        >
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </button>
      ))}
    </div>
  );
}
