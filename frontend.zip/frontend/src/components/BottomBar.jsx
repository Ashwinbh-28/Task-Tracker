export default function BottomBar({ filter, setFilter }) {
  const statuses = ["all", "todo", "in-progress", "done"];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t p-2 flex justify-around sm:hidden">
      {statuses.map((status) => (
        <button
          key={status}
          onClick={() => setFilter(status)}
          className={`px-3 py-1 rounded ${
            filter === status ? "bg-blue-500 text-white" : "bg-gray-200"
          }`}
        >
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </button>
      ))}
    </div>
  );
}
